#ifndef  LOGDAO_H
#define  LOGDAO_H
#include "data.h"
    class  LogDao{
        public:
        void    connectDb(sql_context context,char *userp);
        void    saveData(sql_context context,MatchedLogRec  mlog);
        void    commit(sql_context context);
        void    disConnect(sql_context context);
    }; 
#endif
