#include "userdata.h"        
UserData::UserData(){
     pthread_mutex_init(&mutext,0);
     pthread_cond_init(&pcon,0);
     pthread_cond_init(&ccon,0);
}
UserData::~UserData(){
     pthread_mutex_destroy(&mutext);
     pthread_cond_destroy(&pcon);
     pthread_cond_destroy(&ccon);
}
        /*提供线程安全的访问函数*/
void   UserData::push_back(MatchedLogRec  mlog){
     pthread_mutex_lock(&mutext);
         while(datas.size()>10*1024){
             /*等待生产条件为真*/
             pthread_cond_wait(&pcon,&mutext);  
         }
         datas.push_back(mlog);
         /*肯定可以消费*/
         pthread_cond_signal(&ccon);
     pthread_mutex_unlock(&mutext);
}
MatchedLogRec   UserData::front_and_pop(){
     pthread_mutex_lock(&mutext);
         while(datas.empty()){
             /*等待消费条件为真*/
             pthread_cond_wait(&ccon,&mutext); 
         }
         MatchedLogRec mlog=datas.front();
         datas.pop_front();
         /*肯定可以生产*/
         pthread_cond_broadcast(&pcon);
     pthread_mutex_unlock(&mutext);
         return   mlog;
}  
