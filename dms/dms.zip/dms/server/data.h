#ifndef   DATA_H
#define   DATA_H
     /*登录登出 记录对应的数据结构*/
     struct   LogRec{
         char   logname[32];
         int    pid;
         short  logtype;
         int    logtime;      
         char   logip[257];  
     };
     /*匹配记录对应的数据结构*/
     struct   MatchedLogRec{
         char   logname[32];
         int    pid;
         int    logintime;      
         int    logouttime;  
         int    durations;     
         char   logip[257];  
         /*服务器ip*/
         char   serverip[20]; 
     };
#endif 
