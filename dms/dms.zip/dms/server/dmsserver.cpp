
/* Result Sets Interface */
#ifndef SQL_CRSR
#  define SQL_CRSR
  struct sql_cursor
  {
    unsigned int curocn;
    void *ptr1;
    void *ptr2;
    unsigned int magic;
  };
  typedef struct sql_cursor sql_cursor;
  typedef struct sql_cursor SQL_CURSOR;
#endif /* SQL_CRSR */

/* Thread Safety */
typedef void * sql_context;
typedef void * SQL_CONTEXT;

/* Object support */
struct sqltvn
{
  unsigned char *tvnvsn; 
  unsigned short tvnvsnl; 
  unsigned char *tvnnm;
  unsigned short tvnnml; 
  unsigned char *tvnsnm;
  unsigned short tvnsnml;
};
typedef struct sqltvn sqltvn;

struct sqladts
{
  unsigned int adtvsn; 
  unsigned short adtmode; 
  unsigned short adtnum;  
  sqltvn adttvn[1];       
};
typedef struct sqladts sqladts;

static struct sqladts sqladt = {
  1,1,0,
};

/* Binding to PL/SQL Records */
struct sqltdss
{
  unsigned int tdsvsn; 
  unsigned short tdsnum; 
  unsigned char *tdsval[1]; 
};
typedef struct sqltdss sqltdss;
static struct sqltdss sqltds =
{
  1,
  0,
};

/* File name & Package Name */
struct sqlcxp
{
  unsigned short fillen;
           char  filnam[13];
};
static const struct sqlcxp sqlfpn =
{
    12,
    "dmsserver.pc"
};


static unsigned int sqlctx = 300859;


static struct sqlexd {
   unsigned int   sqlvsn;
   unsigned int   arrsiz;
   unsigned int   iters;
   unsigned int   offset;
   unsigned short selerr;
   unsigned short sqlety;
   unsigned int   occurs;
      const short *cud;
   unsigned char  *sqlest;
      const char  *stmt;
   sqladts *sqladtp;
   sqltdss *sqltdsp;
            void  **sqphsv;
   unsigned int   *sqphsl;
            int   *sqphss;
            void  **sqpind;
            int   *sqpins;
   unsigned int   *sqparm;
   unsigned int   **sqparc;
   unsigned short  *sqpadto;
   unsigned short  *sqptdso;
   unsigned int   sqlcmax;
   unsigned int   sqlcmin;
   unsigned int   sqlcincr;
   unsigned int   sqlctimeout;
   unsigned int   sqlcnowait;
              int   sqfoff;
   unsigned int   sqcmod;
   unsigned int   sqfmod;
            void  *sqhstv[1];
   unsigned int   sqhstl[1];
            int   sqhsts[1];
            void  *sqindv[1];
            int   sqinds[1];
   unsigned int   sqharm[1];
   unsigned int   *sqharc[1];
   unsigned short  sqadto[1];
   unsigned short  sqtdso[1];
} sqlstm = {12,1};

// Prototypes
extern "C" {
  void sqlcxt (void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlcx2t(void **, unsigned int *,
               struct sqlexd *, const struct sqlcxp *);
  void sqlbuft(void **, char *);
  void sqlgs2t(void **, char *);
  void sqlorat(void **, unsigned int *, void *);
}

// Forms Interface
static const int IAPSUCC = 0;
static const int IAPFAIL = 1403;
static const int IAPFTL  = 535;
extern "C" { void sqliem(char *, int *); }

typedef struct { unsigned short len; unsigned char arr[1]; } VARCHAR;
typedef struct { unsigned short len; unsigned char arr[1]; } varchar;

/* cud (compilation unit data) array */
static const short sqlcud0[] =
{12,4130,1,0,0,
5,0,0,0,0,0,60,98,0,0,0,0,0,1,0,
20,0,0,0,0,0,58,99,0,0,1,1,0,1,0,3,109,0,0,
};


#include  <iostream>
#include  <deque>
using  namespace std;
#include <sys/types.h>          
#include <sys/socket.h>
#include <arpa/inet.h>
#include <pthread.h>
#include "data.h"
#include "userdata.h"
#include "logdao.h"
/* exec sql include sqlca;
 */ 
/*
 * $Header: sqlca.h 24-apr-2003.12:50:58 mkandarp Exp $ sqlca.h 
 */

/* Copyright (c) 1985, 2003, Oracle Corporation.  All rights reserved.  */
 
/*
NAME
  SQLCA : SQL Communications Area.
FUNCTION
  Contains no code. Oracle fills in the SQLCA with status info
  during the execution of a SQL stmt.
NOTES
  **************************************************************
  ***                                                        ***
  *** This file is SOSD.  Porters must change the data types ***
  *** appropriately on their platform.  See notes/pcport.doc ***
  *** for more information.                                  ***
  ***                                                        ***
  **************************************************************

  If the symbol SQLCA_STORAGE_CLASS is defined, then the SQLCA
  will be defined to have this storage class. For example:
 
    #define SQLCA_STORAGE_CLASS extern
 
  will define the SQLCA as an extern.
 
  If the symbol SQLCA_INIT is defined, then the SQLCA will be
  statically initialized. Although this is not necessary in order
  to use the SQLCA, it is a good pgming practice not to have
  unitialized variables. However, some C compilers/OS's don't
  allow automatic variables to be init'd in this manner. Therefore,
  if you are INCLUDE'ing the SQLCA in a place where it would be
  an automatic AND your C compiler/OS doesn't allow this style
  of initialization, then SQLCA_INIT should be left undefined --
  all others can define SQLCA_INIT if they wish.

  If the symbol SQLCA_NONE is defined, then the SQLCA variable will
  not be defined at all.  The symbol SQLCA_NONE should not be defined
  in source modules that have embedded SQL.  However, source modules
  that have no embedded SQL, but need to manipulate a sqlca struct
  passed in as a parameter, can set the SQLCA_NONE symbol to avoid
  creation of an extraneous sqlca variable.
 
MODIFIED
    lvbcheng   07/31/98 -  long to int
    jbasu      12/12/94 -  Bug 217878: note this is an SOSD file
    losborne   08/11/92 -  No sqlca var if SQLCA_NONE macro set 
  Clare      12/06/84 - Ch SQLCA to not be an extern.
  Clare      10/21/85 - Add initialization.
  Bradbury   01/05/86 - Only initialize when SQLCA_INIT set
  Clare      06/12/86 - Add SQLCA_STORAGE_CLASS option.
*/
 
#ifndef SQLCA
#define SQLCA 1
 
struct   sqlca
         {
         /* ub1 */ char    sqlcaid[8];
         /* b4  */ int     sqlabc;
         /* b4  */ int     sqlcode;
         struct
           {
           /* ub2 */ unsigned short sqlerrml;
           /* ub1 */ char           sqlerrmc[70];
           } sqlerrm;
         /* ub1 */ char    sqlerrp[8];
         /* b4  */ int     sqlerrd[6];
         /* ub1 */ char    sqlwarn[8];
         /* ub1 */ char    sqlext[8];
         };

#ifndef SQLCA_NONE 
#ifdef   SQLCA_STORAGE_CLASS
SQLCA_STORAGE_CLASS struct sqlca sqlca
#else
         struct sqlca sqlca
#endif
 
#ifdef  SQLCA_INIT
         = {
         {'S', 'Q', 'L', 'C', 'A', ' ', ' ', ' '},
         sizeof(struct sqlca),
         0,
         { 0, {0}},
         {'N', 'O', 'T', ' ', 'S', 'E', 'T', ' '},
         {0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0},
         {0, 0, 0, 0, 0, 0, 0, 0}
         }
#endif
         ;
#endif
 
#endif
 
/* end SQLCA */

/*定义一个数据缓冲池*/
//deque<MatchedLogRec>  datapool;
UserData                datapool;
class   ProducterThread{
/*接受数据的线程的处理函数*/
public:  
static void*    reciveData(void *par){
    ((ProducterThread*)par)->run();
}
public:
void    run(){
    int  afd=this->afd;
    struct MatchedLogRec log;
	//每次满304字节，上面log数据满，就保存到数据库		
	size_t size=0;//同时记录结构体存放的偏离位置,当到达304的时候，存放下一个结构体
	size_t len=sizeof(struct MatchedLogRec);//结构体总长度	
	while(1)
	{
		//线程执行处
		char  data[sizeof(struct MatchedLogRec)];//每次接受的最大字节数
		//因为使用的是TCP，每次接受的数据未必是一个完整的结构,所以要确保304字节的完整性
		size_t t=recv(afd,&data,sizeof(data),0);
		
		if(t<=0 || t==-1)//表示网络断掉了或者接受失败
		{	
			break;//采集任务结束，终止本次采集
		}
		if(t>0)//接受到数据
		{
			if(t<len-size)//未满
			{	
				memcpy(((char*)&log)+size,data,t);//注意指针运算的基本单位
				size+=t;	
			}
			else//满
			{
				memcpy(((char*)&log)+size,data,len-size);//剩余部分放下一个记录
				//cout<<log.logname<<":"<<log.logip<<endl;
				//传递给DAO对象处理-保存
				struct MatchedLogRec rdata;
				memcpy(&rdata,&log,sizeof(log));
				//mdao.save(rdata);  现在不在这里放入数据库
				datapool.push_back(rdata);
				if(t-len+size>0)
				{
					memcpy(&log,data+len-size,t-len+size);
					//由于目标与缓冲等长，所以这里不用判定是否够长
					size=t-len+size;
				}
				else
				{
					size=0;
				}
			}		
		} 
	}
	close(afd);
	cout<<"采集结束"<<endl;
    
}
    private:
    pthread_t  thid;
    int        afd;
    public:
    ProducterThread(int  afd){
        this->afd=afd;
    } 
    public:
    void   start(){
        pthread_create(&thid,0,reciveData,this);   
    }
};
/*写一个消费者线程 负责从池中取出数据*/
class   CustomerThread{
    private:
    pthread_t thid;
    public:
    static  void*  getData(void *par){
         ((CustomerThread*)par)->run();    
    }
    public:
    void  run(){
        /* exec sql  begin declare section; */ 
 
        sql_context context;
        struct sqlca sqlca;   
        /* exec sql  end  declare section; */ 

        /* EXEC SQL ENABLE THREADS; */ 

{
        struct sqlexd sqlstm;
        sqlstm.sqlvsn = 12;
        sqlstm.arrsiz = 0;
        sqlstm.sqladtp = &sqladt;
        sqlstm.sqltdsp = &sqltds;
        sqlstm.stmt = "";
        sqlstm.iters = (unsigned int  )1;
        sqlstm.offset = (unsigned int  )5;
        sqlstm.cud = sqlcud0;
        sqlstm.sqlest = (unsigned char  *)&sqlca;
        sqlstm.sqlety = (unsigned short)256;
        sqlstm.occurs = (unsigned int  )0;
        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


        /* EXEC SQL CONTEXT ALLOCATE :context; */ 

{
        struct sqlexd sqlstm;
        sqlstm.sqlvsn = 12;
        sqlstm.arrsiz = 1;
        sqlstm.sqladtp = &sqladt;
        sqlstm.sqltdsp = &sqltds;
        sqlstm.stmt = "";
        sqlstm.iters = (unsigned int  )1;
        sqlstm.offset = (unsigned int  )20;
        sqlstm.cud = sqlcud0;
        sqlstm.sqlest = (unsigned char  *)&sqlca;
        sqlstm.sqlety = (unsigned short)256;
        sqlstm.occurs = (unsigned int  )0;
        sqlstm.sqhstv[0] = (         void  *)&context;
        sqlstm.sqhstl[0] = (unsigned int  )sizeof(void *);
        sqlstm.sqhsts[0] = (         int  )0;
        sqlstm.sqindv[0] = (         void  *)0;
        sqlstm.sqinds[0] = (         int  )0;
        sqlstm.sqharm[0] = (unsigned int  )0;
        sqlstm.sqadto[0] = (unsigned short )0;
        sqlstm.sqtdso[0] = (unsigned short )0;
        sqlstm.sqphsv = sqlstm.sqhstv;
        sqlstm.sqphsl = sqlstm.sqhstl;
        sqlstm.sqphss = sqlstm.sqhsts;
        sqlstm.sqpind = sqlstm.sqindv;
        sqlstm.sqpins = sqlstm.sqinds;
        sqlstm.sqparm = sqlstm.sqharm;
        sqlstm.sqparc = sqlstm.sqharc;
        sqlstm.sqpadto = sqlstm.sqadto;
        sqlstm.sqptdso = sqlstm.sqtdso;
        sqlcxt((void **)0, &sqlctx, &sqlstm, &sqlfpn);
}


        /* EXEC SQL CONTEXT USE :context; */ 

        LogDao  logdao;
        logdao.connectDb(context,"system/abc123"); 
        while(1){
            MatchedLogRec  mlog=datapool.
                front_and_pop();
            /*cout<<mlog.logname<<":"<<mlog.logip
     <<endl;*/
           logdao.saveData(context,mlog);
           logdao.commit(context);
        } 
    }
    public:
    void  start(){
        pthread_create(&thid,0,getData,this);
    }
};
int main(){
    int fd=socket(AF_INET,SOCK_STREAM,0);
    if(fd==-1){
        cout<<"init socket failed"<<endl;
    } 
    struct  sockaddr_in   addr={0};
    addr.sin_family=AF_INET;
    addr.sin_port=htons(8899);
    addr.sin_addr.s_addr=INADDR_ANY;
    int  bfd=bind(fd,(sockaddr*)&addr,sizeof addr);
    if(bfd==-1){
        cout<<"bind failed"<<endl;
    }  
    listen(fd,10);
    //CustomerThread   customer;
    //customer.start();
    CustomerThread   customer2;
    customer2.start();
    while(1){
    struct  sockaddr_in   caddr={0};
    socklen_t   len=sizeof  caddr;
    int  afd=accept(fd,(sockaddr*)&caddr,&len);
    if(afd==-1){
        cout<<"accept client  failed"<<endl; 
    } 
    /*创建线程为 客户端服务
    pthread_t   thid;
    pthread_create(&thid,0,reciveData,&afd); */
    ProducterThread   producter(afd);
    producter.start(); 
    /*ProducterThread     *producter=new 
        ProducterThread(afd);      
    producter->start(); */
    
    }
    close(fd);
}

