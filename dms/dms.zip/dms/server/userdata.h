#ifndef  USERDATA_H
#define  USERDATA_H
#include  "data.h"
#include <deque>
#include <pthread.h>
using namespace std;
    class   UserData{
        private:
        /*保证线程安全*/
        pthread_mutex_t   mutext;
        /*真正存储数据的*/
        deque<MatchedLogRec>  datas;
        /*生产和消费的条件*/
        pthread_cond_t     pcon;
        pthread_cond_t     ccon;
        public:
        UserData();    
        ~UserData();
        /*提供线程安全的访问函数*/
        public:
        void     push_back(MatchedLogRec  mlog);
        MatchedLogRec   front_and_pop();  
    };    
#endif
