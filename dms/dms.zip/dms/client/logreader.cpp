#include "logreader.h"       
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <cstring>
#include <arpa/inet.h>
#include <stdio.h>
#include <iostream>
using namespace std;
LogReader::LogReader(){
    strcpy(backFileName,"wtmpx");
}
LogReader::~LogReader(){}
/*调用之后 返回一个匹配好的 发送集合*/        
list<MatchedLogRec>  LogReader::readLogs(){
    backup();
    readFailLogins();
    cout<<"logins:"<<logins.size()<<endl;
    cout<<"logouts:"<<logouts.size()<<endl;  
    readBackupFile();
    cout<<"--------------------"<<endl;
    /*看两个集合的变化*/
    cout<<"logins:"<<logins.size()<<endl;
    cout<<"logouts:"<<logouts.size()<<endl;  
    matchLogRec();
    /*看匹配了多少条 */
    cout<<"matches:"<<matches.size()<<endl;
    /*看logins中剩余了多少条*/
    cout<<"logins:"<<logins.size()<<endl;
    cout<<"logouts:"<<logouts.size()<<endl;  
    saveFailLogins();
    return   matches;
}
  void LogReader:: backup(){
      /*20130216160540wtmpx*/ 
      cout<<"1.backup logfile"<<endl;
      //sprintf(backFileName,"%4d02d02d....")
  }
  void LogReader:: readFailLogins(){
      cout<<"2.read fail matched logins"<<endl;
      /*以结构体为单位读取文件 把读取的数据放入登入集合*/
  }
  void LogReader:: readBackupFile(){
      cout<<"3.read backup  log file"<<endl;
      /*先得到文件大小  算出循环次数
       读取数据 包装对象  把对象按照登录
       类型7，8分别放入集合*/
      int  fd=open(backFileName,O_RDONLY);
      if(fd==-1){
          cout<<"open backfile  failed"<<endl;
      }     
      struct   stat   fs={0};
      fstat(fd,&fs);
      cout<<fs.st_size<<endl; 
      int  loopcount=fs.st_size/372;
      for(int i=0;i<loopcount;i++){
          LogRec   logrec={0};
          read(fd,&logrec.username,32);
          lseek(fd,36,SEEK_CUR);
          read(fd,&logrec.pid,4);
          logrec.pid=htonl(logrec.pid);
          read(fd,&logrec.logtype,2);
          logrec.logtype=htons(logrec.logtype);
          lseek(fd,6,SEEK_CUR);
          read(fd,&logrec.logtime,4); 
          logrec.logtime=htonl(logrec.logtime);
          lseek(fd,30,SEEK_CUR);
          read(fd,&logrec.logip,257);
          //cout<<logrec.username<<":"<<logrec.logtype<<endl;
          /*把剩余的数据读取出来  
            把用户名是点开头的数据过滤掉
            把logtype是7放入logins  
            把logtype是8的放入logouts*/ 
          if(logrec.username[0]!='.'){
               if(logrec.logtype==7){
                    logins.push_back(logrec);
               }else if(logrec.logtype==8){
                    logouts.push_back(logrec); 
               }else{
                    ; 
               }
          }  
          lseek(fd,1,SEEK_CUR);   
      }
  }
  void LogReader:: matchLogRec(){
      cout<<"4.match log rec"<<endl;
      /*1.循环的从登出集合中取出一条数据 
        2.在登入集合中循环查找 与之匹配的登入记录
          username  pid  logip相同则匹配
          如果匹配  则构建匹配记录  
          放入匹配集合
          删除登入记录  结束本次查找
          如果不匹配 则继续查找的循环 直到查找结束
        3.清空登出集合*/
        list<LogRec>::iterator   iit;
        list<LogRec>::iterator   oit;
        for(oit=logouts.begin();oit!=logouts.end();oit++){
            /*每次循环把迭代器指向集合的第一个元素*/
            iit=logins.begin();
            while(iit!=logins.end()){
                if(!strcmp(iit->username,oit->username)
                   && iit->pid==oit->pid &&
                   !strcmp(iit->logip,oit->logip)){
                     MatchedLogRec  mlog={0};
                     sprintf(mlog.username,"%s",
                             iit->username);
                     mlog.pid=iit->pid;
                     mlog.logintime=iit->logtime;
                     mlog.logouttime=oit->logtime;
                     mlog.durations=mlog.logouttime-
                                    mlog.logintime;
                     strcpy(mlog.logip,iit->logip);   
                     /*给mlog.serverip赋值*/  
                     matches.push_back(mlog);
                     logins.erase(iit);
                     break;  
                }
                iit++;
            } 
        }
        logouts.clear();
  }
  void LogReader:: saveFailLogins(){
      cout<<"5.save  fail  matched logins"<<endl; 
      /*以结构体为单位 写文件*/
  }         
