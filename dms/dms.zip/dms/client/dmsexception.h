#ifndef  DMSEXCEPTION_H
#define  DMSEXCEPTION_H
#include <string.h>
    class  DmsClientException{
        private:
        char  msg[256]; 
        public:
        DmsClientException(){
            strcpy(msg,"dms client exception");
        }
        DmsClientException(const char *msg){ 
            strcpy(this->msg,msg);   
        } 
        virtual const char * what()const throw(){
            return  msg;  
        }
    };
    class  DmsSenderException:public  DmsClientException{
        public:
        DmsSenderException():DmsClientException("dms sender exception"){
           
        }    
        DmsSenderException(const char *msg):DmsClientException(msg){
        }
       /* const  char *what()const throw(){
            return  "this is dms sender exception";
        }*/
    };
    class DmsInitNetWorkException:public DmsSenderException
    {    public:
          DmsInitNetWorkException():DmsSenderException("dms init netWork exception"){
    
          } 
          DmsInitNetWorkException(const char *msg):DmsSenderException(msg){
    
          } 
    };
    class DmsSendDataException:public DmsSenderException{
         public:
         DmsSendDataException():DmsSenderException("dms send data exception"){

         }
         DmsSendDataException(const char *msg):DmsSenderException(msg){
         }  
    };
#endif

