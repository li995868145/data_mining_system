/*dms 项目中用到的数据结构*/
#ifndef  DATA_H
#define  DATA_H
     /*登入 登出的记录类对应的数据结构*/
     struct  LogRec{
          char  username[32];
          int   pid;
          short logtype;
          int   logtime;
          char  logip[257];       
     };
     /*匹配日志记录类对应的数据结构*/  
     struct  MatchedLogRec{
          char  username[32];
          int   pid;
          int   logintime;
          int   logouttime;
          int   durations;
          char  logip[257];  
          /*对每台服务器的数据进行统计*/ 
          char  severip[20];         
     };
#endif

