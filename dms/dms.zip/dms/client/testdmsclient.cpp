#include "logreader.h"
#include "logsender.h"
#include <list>
using namespace std;
int main(){
    LogReader   logreader;
    list<MatchedLogRec> matches=
    logreader.readLogs();
    LogSender   logsender;
    logsender.sendMatches(&matches);
}

